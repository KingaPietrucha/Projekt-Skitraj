## Ryzyko projektowe
- ograniczone zasoby ludzkie  
- ograniczony czas (1h)
## Ryzyko produktowe
- niska jakość oprogramowania