### Test Plan – www.skitraj.pl
Strona internetowa www.skitraj.pl świadczy usługi przechowywania rzeczy, wynajmowania pudełek do przechowywania oraz umożliwia kupno produktów niezbędnych do przechowywania. 
## Wstęp
Głównym celem testów jest sprawdzenie funkcjonalności strony.
## Przedmioty testów:
- 	Rejestracja
- 	Logowanie
- 	Dodanie opinii
-	Dodanie użytkownika do newsletter
-	Dodanie produktu do koszyka
##  Kryteria  zaliczenie/niezaliczenia testów
Wykonanie zaprojektowanych przypadków testowych.
##  Kryteria wejścia/wyjścia
# 1. Kryteria wejścia:
•	działające i skonfigurowane środowisko testowe
# 2. Kryteria wyjścia
•	wszystkie przypadki testowe zostały zakończone pozytywnie
##  Środowisko testowe
-	Produkcyjne
-	System Windows 11 (64 bit)
-	Przeglądarki biorące udział w testach: Chrome
##  Raport z testów
-	Lista zrealizowanych przypadków testowych wraz ze statusem
-	Inne raporty z testów
## Narzędzia:
-	Greenshot
-	ScreenRec
-	Jira
-	TestRail
-	DevTools
-	Selenium IDE

